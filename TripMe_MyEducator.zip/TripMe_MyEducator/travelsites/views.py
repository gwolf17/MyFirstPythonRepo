from django.shortcuts import render
from django.http import HttpResponse
from travelsites.models import TripCategory, Destination

def showtripsPageView(request):
    return render(request, 'travelsites/showTrips.html')

def africaPageView(request):
    id = TripCategory.objects.get(description = "Africa")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)

def asiaPageView(request):
    id = TripCategory.objects.get(description = "Asia")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)

def australiaPageView(request):
    id = TripCategory.objects.get(description = "Australia")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)

def europePageView(request):
    id = TripCategory.objects.get(description = "Europe")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)

def northamericaPageView(request):
    id = TripCategory.objects.get(description = "North America")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)

def southamericaPageView(request):
    id = TripCategory.objects.get(description = "South America")
    data = Destination.objects.get(tripcategory_id = id)
    context = {
        "area" : id.description,
        "image" : data.photo_main
    }
    return render(request, 'travelsites/displaytrips.html', context)