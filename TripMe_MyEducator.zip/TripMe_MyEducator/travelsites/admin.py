from django.contrib import admin
from .models import Customer, TripCategory, Destination

admin.site.register(Customer)
admin.site.register(TripCategory)
admin.site.register(Destination)