from django.urls import path
from .views import indexPageView, aboutPageView
from .views import showCustomersPageView, showSingleCustomerPageView, updateCustomersPageView, deleteCustomerPageView, addCustomerPageView, addCustomerDestinationPageView, addCustDestPageView

urlpatterns = [  
    path("about/", aboutPageView, name="about"),
    path("customers/", showCustomersPageView, name="customers"),
    path("showCustomers/<int:cust_id>", showSingleCustomerPageView, name="showSingleCustomer"),
    path("updateCustomers/", updateCustomersPageView, name="updateCust"),
    path("deleteCustomers/<int:cust_id>/", deleteCustomerPageView, name="deleteCustomer"),
    path("addCustomer/", addCustomerPageView, name="addCustomer"),
    path("addCustomerDestination/<int:cust_id>/", addCustomerDestinationPageView, name="addCustomerDestination"),
    path("addCustDest/", addCustDestPageView, name="addCustDest"),
    path("", indexPageView, name="index"),
] 