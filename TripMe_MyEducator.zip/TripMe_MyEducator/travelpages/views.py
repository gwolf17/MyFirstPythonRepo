from django.http import HttpResponse
from django.shortcuts import render
from travelsites.models import Customer, Destination

def indexPageView(request) :
    return render(request, 'travelpages/index.html') 

def aboutPageView(request) :
    return render(request, 'travelpages/about.html')

def showCustomersPageView(request):
    data = Customer.objects.all()

    context = {
        "cust" : data
    }
    return render(request, 'travelpages/showCustomers.html', context)

def showSingleCustomerPageView(request, cust_id):
    data = Customer.objects.get(id = cust_id)
    destinations = data.destination.all()

    context = {
        "record" : data,
        "dest" : destinations
    }
    return render(request, 'travelpages/editCustomer.html', context)

def updateCustomersPageView(request):
    if request.method == "POST":
        cust_id = request.POST['cust_id']

        customer = Customer.objects.get(id=cust_id)

        customer.first_name = request.POST['first_name']
        customer.last_name = request.POST['last_name']
        customer.user_name = request.POST['user_name']
        customer.password = request.POST['password']
        customer.email = request.POST['email']
        customer.phone = request.POST['phone']

        customer.save()

    return showCustomersPageView(request)

def deleteCustomerPageView(request, cust_id):
    data = Customer.objects.get(id = cust_id)

    data.delete()

    return showCustomersPageView(request)

def addCustomerPageView(request):
    if request.method == 'POST':
        customer = Customer()

        customer.first_name = request.POST['first_name']
        customer.last_name = request.POST['last_name']
        customer.user_name = request.POST['user_name']
        customer.password = request.POST['password']
        customer.email = request.POST['email']
        customer.phone = request.POST['phone']

        customer.save()

        return showCustomersPageView(request)
    else:
        return render(request, 'travelpages/addCustomer.html')

def addCustomerDestinationPageView(request, cust_id):
    data = Customer.objects.get(id = cust_id)
    destinations = data.destination.all()

    avail_dest = Destination.objects.exclude(id__in=data.destination.all())

    context = {
        "record" : data,
        "dest" : destinations,
        "avail" : avail_dest
    }

    return render(request, 'travelpages/addCustomerDest.html', context)

def addCustDestPageView(request):
    if request.method =='POST':
        cust_id = request.POST['cust_id']
        customer = Customer.objects.get(id=cust_id)

        dest = request.POST['cust_dest']
        customer.destination.add(Destination.objects.get(id=dest))

        return showCustomersPageView(request)