from django.apps import AppConfig


class TravelpagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'travelpages'
