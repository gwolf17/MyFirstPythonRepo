from django.urls import path
from .views import showtripsPageView, africaPageView, asiaPageView, australiaPageView, europePageView, northamericaPageView, southamericaPageView

urlpatterns = [

    path("africa/", africaPageView, name="africa"),    
    path("asia/", asiaPageView, name="asia"),
    path("australia/", australiaPageView, name="australia"),
    path("europe/", europePageView, name="europe"),
    path("northamerica/", northamericaPageView, name="northamerica"),
    path("southamerica/", southamericaPageView, name="southamerica"),
    path("", showtripsPageView, name = "showtrips"),
] 