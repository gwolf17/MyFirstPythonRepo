from django.shortcuts import render
from django.http import HttpResponse

def showtripsPageView(request):
    return render(request, 'travelsites/showTrips.html')

def africaPageView(request):
    context = {
        "area" : "Africa"
    }
    return render(request, 'travelsites/displaytrips.html', context)

def asiaPageView(request):
    context = {
        "area" : "Asia"
    }
    return render(request, 'travelsites/displaytrips.html', context)

def australiaPageView(request):
    context = {
        "area" : "Australia"
    }
    return render(request, 'travelsites/displaytrips.html', context)

def europePageView(request):
    context = {
        "area" : "Europe"
    }
    return render(request, 'travelsites/displaytrips.html', context)

def northamericaPageView(request):
    context = {
        "area" : "North America"
    }
    return render(request, 'travelsites/displaytrips.html', context)

def southamericaPageView(request):
    context = {
        "area" : "South America"
    }
    return render(request, 'travelsites/displaytrips.html', context)