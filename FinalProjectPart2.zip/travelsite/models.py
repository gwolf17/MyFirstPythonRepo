from django.db import models

# Create your models here.

#USER CLASS
class User(models.Model):
    user_first_name = models.CharField(max_length=20)
    user_last_name = models.CharField(max_length=30)
    user_address = models.CharField(max_length=50)
    user_city = models.CharField(max_length=25)
    user_state = models.CharField(max_length=2)
    user_zip = models.IntegerField
    user_email = models.EmailField(max_length=30)
    user_phone = models.CharField(max_length=10)
    user_username = models.CharField(max_length=25)
    user_password = models.CharField(max_length=25)

    #Create attribute to return the user's full name
    @property
    def full_name(self):
        return '%s %s' % (self.user_first_name, self.user_last_name)

    #Return full_name attribute
    def __str__(self):
        return (self.full_name)

    #Create attribute to return the user's address
    @property
    def full_address(self):
        return '%s %s, %s %s' % (self.user_address, self.user_city, self.user_state, self.user_zip)

    #Return full_address, email, phone, username, and password attributes
    def __str__(self):
        return (self.full_address)

    def __str__(self):
        return (self.user_email)

    def __str__(self):
        return (self.user_phone)

    def __str__(self):
        return (self.user_username)

    def __str__(self):
        return (self.user_password)

#ITINERARY CLASS
class Itinerary(models.Model):
    #One-to-many relationship with User Class
    user_id = models.ForeignKey('User', blank=False, on_delete=models.CASCADE)
    start_date = models.DateField
    end_date = models.DateField
    activities = models.ManyToManyField('Location', through='Activity')

    #Return start date
    def __str__(self):
        return (self.start_date)

    #Return end date
    def __str__(self):
        return (self.end_date)

#LOCATION_CATEGORY CLASS
class Location_Category(models.Model):
    type = models.CharField(max_length=30)
    #Picture of location
    photo = models.ImageField(upload_to='photos')

    #Return type
    def __str__(self):
        return (self.type)

#ACTIVITY CLASS (linking Itinerary and Location)
class Activity(models.Model):
    itinerary = models.ForeignKey('Itinerary', on_delete=models.CASCADE)
    location = models.ForeignKey('Location', on_delete=models.CASCADE)
    activity_start_date = models.DateField
    activity_end_date = models.DateField

    #Return start date
    def __str__(self):
        return (self.activity_start_date)

    #Return end date
    def __str__(self):
        return (self.activity_end_date)

#LOCATION CLASS
class Location(models.Model):
    location_name = models.CharField(max_length=30)
    location_address = models.CharField(max_length=50)
    location_city = models.CharField(max_length=25)
    location_state = models.CharField(max_length=2)
    #One-to-Many relationship with Location_Category Class
    location_category = models.ForeignKey('Location_Category', blank=False, on_delete=models.CASCADE)

    #Return location name
    def __str__(self):
        return (self.location_name)
    
    #Create address attribute
    @property
    def location_full_address(self):
        return '%s %s, %s' % (self.location_address, self.location_city, self.location_state)

    #Return full address attribute
    def __str__(self):
        return (self.location_full_address)