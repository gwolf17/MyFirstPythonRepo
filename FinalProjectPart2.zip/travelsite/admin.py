from django.contrib import admin
from .models import User, Itinerary, Location, Activity, Location_Category

# Register your models here.
admin.site.register(User)
admin.site.register(Itinerary)
admin.site.register(Location)
admin.site.register(Activity)
admin.site.register(Location_Category)