from django.shortcuts import render
from django.http import HttpResponse
from .models import User, Itinerary, Location_Category, Activity, Location


def loginPageView(request):
    return render(request, 'travelsite/login.html')

def indexPageView(request):
    return render(request, 'travelsite/index.html')

def locationPageView(request):
    return render(request, 'travelsite/location.html')

def accountPageView(request):
    return render(request, 'travelsite/account.html')

def itineraryPageView(request):
    return render(request, 'travelsite/itinerary.html')

def activityPageView(request):
    return render(request, 'travelsite/activity.html')


# Forms Needed:
'''
- Login
- Filter locations to view them?
- Add an itinerary
- Edit or delete an itinerary
- Add an activity (location) to an itinerary
- Edit or delete an activity on the itinerary
'''

# Templates needed:
'''
- Login page
- Home page (index)
- Account page
- View locations
- View itineraries
- Add itinerary
- Edit itinerary (similar layout to add itinerary)
- Add activity (location) to an itinerary
'''