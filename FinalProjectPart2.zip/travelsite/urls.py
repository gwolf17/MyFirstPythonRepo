from django.urls import path
from .views import indexPageView, locationPageView, accountPageView, itineraryPageView, loginPageView, activityPageView

urlpatterns = [
    path("", indexPageView, name="index"),
    path("location/", locationPageView, name="location"),
    path("account/", accountPageView, name="account"),
    path("itinerary/", itineraryPageView, name="itinerary"),
    path("login/", loginPageView, name="login"),
    path("activity/", activityPageView, name="activity"),
]
