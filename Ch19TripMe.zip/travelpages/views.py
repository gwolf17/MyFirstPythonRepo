from django.http import HttpResponse
from django.shortcuts import render

def indexPageView(request) :
    return render(request, 'travelpages/index.html') 

def aboutPageView(request) :
    return render(request, 'travelpages/about.html')