from django.shortcuts import render
from django.http import HttpResponse

def indexPageView(request):
    return HttpResponse("Index page under construction.")

def locationPageView(request):
    return HttpResponse("Future list of locations.")

def accountPageView(request):
    return HttpResponse("Account details. Username, password, etc.")

def itineraryPageView(request):
    return HttpResponse("List of user's itinerarys.")